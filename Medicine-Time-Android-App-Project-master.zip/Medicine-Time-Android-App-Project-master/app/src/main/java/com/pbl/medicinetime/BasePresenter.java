package com.pbl.medicinetime;

/**
 * Created by pbl on 12/07/17.
 */

public interface BasePresenter {

    void start();
}
