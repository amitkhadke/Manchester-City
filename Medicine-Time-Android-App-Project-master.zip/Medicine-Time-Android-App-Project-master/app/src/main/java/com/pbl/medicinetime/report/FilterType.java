package com.pbl.medicinetime.report;

/**
 * Created by pbl on 13/07/17.
 */

public enum  FilterType {

    ALL_MEDICINES,

    TAKEN_MEDICINES,

    IGNORED_MEDICINES
}
