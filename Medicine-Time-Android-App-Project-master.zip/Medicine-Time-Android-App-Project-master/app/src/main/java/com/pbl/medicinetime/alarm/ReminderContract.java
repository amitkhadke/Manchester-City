package com.pbl.medicinetime.alarm;

import com.pbl.medicinetime.BasePresenter;
import com.pbl.medicinetime.BaseView;
import com.pbl.medicinetime.data.source.History;
import com.pbl.medicinetime.data.source.MedicineAlarm;

/**
 * Created by pbl on 13/07/17.
 */

public interface ReminderContract {

    interface View extends BaseView<Presenter> {

        void showMedicine(MedicineAlarm medicineAlarm);

        void showNoData();

        boolean isActive();

        void onFinish();

    }

    interface Presenter extends BasePresenter {

        void finishActivity();

        void onStart(long id);

        void loadMedicineById(long id);

        void addPillsToHistory(History history);

    }
}
