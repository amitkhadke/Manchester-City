package com.pbl.medicinetime;

import android.content.Context;
import androidx.annotation.NonNull;


import com.pbl.medicinetime.data.source.MedicineRepository;
import com.pbl.medicinetime.data.source.local.MedicinesLocalDataSource;


/**
 * Created by pbl on 13/05/17.
 */

public class Injection {

    public static MedicineRepository provideMedicineRepository(@NonNull Context context) {
        return MedicineRepository.getInstance(MedicinesLocalDataSource.getInstance(context));
    }
}